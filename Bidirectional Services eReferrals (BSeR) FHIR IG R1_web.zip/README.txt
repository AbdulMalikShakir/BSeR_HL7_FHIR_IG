

Structure of this package:

index.html

Fonts:
fonts/glyphicons-halflings-regular.eot
fonts/glyphicons-halflings-regular.svg
fonts/glyphicons-halflings-regular.ttf
fonts/glyphicons-halflings-regular.woff

Styles:
css/bootstrap.min.css
css/Site.css
css/IGView.css
css/highlight.css
css/joint.min.css

Scripts:
js/jquery-1.10.2.min.js
js/bootstrap.js
js/angular.min.js
js/angular-route.min.js
js/ui-bootstrap-tpls-2.5.0.min.js
js/highlight.min.js
js/angular-highlight.min.js
js/jquery-highlight-5.js
js/IGView.js
js/vkbeautify.0.99.00.beta.js
js/joint.min.js
js/lodash.min.js
js/backbone-min.js
js/dagre.core.min.js
js/graphlib.core.min.js
js/joint.layout.DirectedGraph.min.js

Images:
